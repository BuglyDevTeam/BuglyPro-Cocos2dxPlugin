//
//  BuglyLuaAgent.cpp
//  Bugly
//
//  Copyright © 2024年 Bugly. All rights reserved.
//
//

#include "BuglyLuaAgent.h"

#include "cocos2d.h"
//#include "CCLuaEngine.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"

#include "CrashReport.h"

#ifndef CATEGORY_LUA_EXCEPTION
#define CATEGORY_LUA_EXCEPTION 6
#endif

#pragma mark - BuglyLuaAgent

/*
cocos2d::LuaEngine * BuglyLuaAgent::getLuaEngine() {
#if COCOS2D_VERSION >= 0x00030000
    return cocos2d::LuaEngine::getInstance();
#else
    return cocos2d::CCLuaEngine::defaultEngine();
#endif
}

lua_State *BuglyLuaAgent::getLuaState() {
    return BuglyLuaAgent::getLuaEngine()->getLuaStack()->getLuaState();
}
*/

void BuglyLuaAgent::registerLuaExceptionHandler(cocos2d::LuaEngine * engine) {
	lua_State *L = engine->getLuaStack()->getLuaState();

	lua_register(L, "buglyReportLuaException", BuglyLuaAgent::reportLuaException);
	lua_register(L, "buglySetUserId", BuglyLuaAgent::setUserId);
	lua_register(L, "buglyAddUserValue", BuglyLuaAgent::addUserValue);
	lua_register(L, "buglySetScene", BuglyLuaAgent::setScene);
    lua_register(L, "buglyTestCrash", BuglyLuaAgent::testCrash);
}

int BuglyLuaAgent::reportLuaException(lua_State *L) {
	const char* type = "";
	const char* msg = lua_tostring(L, 1);
	const char* traceback = lua_tostring(L, 2);
	bool quit = lua_toboolean(L, 3);

	CrashReport::reportException(CATEGORY_LUA_EXCEPTION, type, msg, traceback, quit);

	return 0;
}

int BuglyLuaAgent::setUserId(lua_State *L) {
	CCLOG("-> %s", __PRETTY_FUNCTION__);
	const char* userId = lua_tostring(L, 1);

	CrashReport::setUserId(userId);

	return 0;
}

int BuglyLuaAgent::addUserValue(lua_State *L) {
	CCLOG("-> %s", __PRETTY_FUNCTION__);
	const char* key = lua_tostring(L, 1);
	const char* value = lua_tostring(L, 2);

	CrashReport::addUserValue(key, value);

	return 0;
}

int BuglyLuaAgent::setScene(lua_State *L) {
	CCLOG("-> %s", __PRETTY_FUNCTION__);
	const char* scene = lua_tostring(L, 1);

	CrashReport::setScene(scene);
	return 0;
}

int BuglyLuaAgent::testCrash(lua_State *L) {
	CCLOG("-> %s", __PRETTY_FUNCTION__);
#if defined(COCOS2D_DEBUG)
	int crashType = (int)lua_tointeger(L, 1);

	CrashReport::TestCrash(crashType);
#endif // COCOS2D_DEBUG
	return 0;
}
