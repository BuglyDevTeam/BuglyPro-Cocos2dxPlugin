//
//  BuglyJSAgent.cpp
//  Bugly
//
//  Copyright © 2024年 Bugly. All rights reserved.
//
//

#include "BuglyJSAgent.h"

#include "cocos2d.h"
//#include "JavaScriptCore/JavaScriptCore.h"
//
//#include "jsb_helper.h"
//#include "jsapi.h"
//#include "jsfriendapi.h"
//#include "cocos2d_specifics.hpp"
#include "scripting/js-bindings/manual/ScriptingCore.h"
#include "scripting/js-bindings/manual/jsb_helper.h"

#include <string.h>

#include "CrashReport.h"

#ifndef CATEGORY_JS_EXCEPTION
#define CATEGORY_JS_EXCEPTION 5
#endif

void BuglyJSAgent::registerJSFunctions(JSContext *cx, BLYJSObject global){
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
    // register js function with c++ function
    JS_DefineFunction(cx, global, "buglySetUserId", BuglyJSAgent::setUserId,1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, global, "buglyAddUserValue", BuglyJSAgent::addUserValue,2, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, global, "buglySetScene", BuglyJSAgent::setScene, 1, JSPROP_READONLY | JSPROP_PERMANENT);
    JS_DefineFunction(cx, global, "buglyTestCrash", BuglyJSAgent::testCrash, 1, JSPROP_READONLY | JSPROP_PERMANENT);
}

void BuglyJSAgent::registerJSExceptionHandler(JSContext *cx){
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
    JS_SetErrorReporter(cx, BuglyJSAgent::reportJSError);
}

void BuglyJSAgent::reportJSError(JSContext *cx, const char *message, JSErrorReport *report){
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
    const char* format = "%s:%u:%s\n";
    const char* filename = report != nullptr && report->filename ? report->filename : "<no filename=\"filename\">";

    size_t bufLen = strlen(format) + strlen(filename) + strlen(message) + 32;
    char* traceback = (char*)malloc(bufLen);
    memset(traceback, 0, bufLen);
    sprintf(traceback, format, filename, (unsigned int)report->lineno, message);

    const char *reason = strstr(message, ":");
    const char *name = message;
    
    if (reason == nullptr) {
        reason = message;
    } else {
        size_t len = strlen(message) - strlen(reason);
        if (len > 0) {
            name = strndup(message, len);
            reason ++;
        }
    }
    
    CrashReport::reportException(CATEGORY_JS_EXCEPTION, (name != message) ? name : "JSError", message, traceback);
    free(traceback);
    
    if (name != message) {
        free((void*)name);
    }
}

bool BuglyJSAgent::setUserId(JSContext *cx, unsigned argc, JS::Value *vp){
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
    if (argc > 0) {
#if COCOS2D_VERSION >= 0x00030500
        JS::CallArgs args = JS::CallArgsFromVp(argc, vp);
    
        const char *userId;
        jsval_to_charptr(cx, args.get(0), &userId);
        CrashReport::setUserId(userId);
        
        args.rval().setUndefined();
#else
        jsval *argvp = JS_ARGV(cx, vp);
        
        const char *userId;
        jsval_to_charptr(cx, *argvp++, &userId);
        CrashReport::setUserId(userId);
#endif
    }
    
    return true;
}

bool BuglyJSAgent::addUserValue(JSContext *cx, unsigned argc, JS::Value *vp) {
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
    if (argc > 1) {
#if COCOS2D_VERSION >= 0x00030500
        JS::CallArgs args = JS::CallArgsFromVp(argc, vp);

        const char *key, *value;
        jsval_to_charptr(cx, args.get(0), &key);
        jsval_to_charptr(cx, args.get(1), &value);
        CrashReport::addUserValue(key, value);
        
        args.rval().setUndefined();
        
#else
        jsval *argvp = JS_ARGV(cx, vp);
        
        const char *key, *value;
        jsval_to_charptr(cx, *argvp++, &key);
        jsval_to_charptr(cx, *argvp++, &value);
        
        CrashReport::addUserValue(key, value);
#endif
    }
    
    return true;
}

bool BuglyJSAgent::setScene(JSContext *cx, unsigned argc, JS::Value *vp) {
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
    if (argc > 0) {
#if COCOS2D_VERSION >= 0x00030500
        JS::CallArgs args = JS::CallArgsFromVp(argc, vp);
    
        const char *scene;
        jsval_to_charptr(cx, args.get(0), &scene);
        CrashReport::setScene(scene);
        
        args.rval().setUndefined();
#else
        jsval *argvp = JS_ARGV(cx, vp);
        
        const char *scene;
        jsval_to_charptr(cx, *argvp++, &scene);
        CrashReport::setScene(scene);
#endif
    }
    return true;
}

bool BuglyJSAgent::testCrash(JSContext *cx, unsigned argc, JS::Value *vp) {
    CCLOG("-> %s", __PRETTY_FUNCTION__);
    
#if defined(COCOS2D_DEBUG)

    if (argc > 0) {
#if COCOS2D_VERSION >= 0x00030500
        JS::CallArgs args = JS::CallArgsFromVp(argc, vp);
    
        int crashType = 0;
        jsval_to_int(cx, args.get(0), &crashType);
        CrashReport::TestCrash(crashType);
        
        args.rval().setUndefined();
#else
        jsval *argvp = JS_ARGV(cx, vp);
        
        int crashType = 0;
        jsval_to_int(cx, *argvp++, &crashType);
        CrashReport::TestCrash(crashType);
#endif
    }

#endif // COCOS2D_DEBUG
    return true;
}