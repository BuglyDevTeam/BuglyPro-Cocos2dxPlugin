//
//  BuglyNetworkMonitor.h
//  Bugly
//
//  Created by Tianwu Wang on 2023/8/15.
//  Copyright © 2023 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

API_AVAILABLE(macos(12.0), ios(15.0), watchos(8.0), tvos(15.0))
@interface BuglyNetworkMonitor : NSObject

@end

NS_ASSUME_NONNULL_END
