//
//  BuglyJSAgentCreator.h
//  Bugly
//
//  Copyright © 2025年 Bugly. All rights reserved.
//
//

#ifndef __BUGLY_JS_AGENT_CREATOR_H__
#define __BUGLY_JS_AGENT_CREATOR_H__

class BuglyJSAgentCreator {
public:
    /// 注册js层的bugly接口:
    /// BuglyPro.setUserID("js_user_id");                       // 设置userid的js接口
    /// BuglyPro.addUserValue("js_key", "js_value");            // 设置自定义数据的js接口
    /// BuglyPro.setAppChannel("app_channel");                  // 设置渠道名称   
    /// BuglyPro.setAppVersion("1.234.5678");                   // 设置游戏版本 
    /// BuglyPro.setDeviceID("1234-5678-9012");                 // 设置设备ID，如果业务不设置，bugly将自己生成一个guid作为设备id   
    /// BuglyPro.setScene("js_scene");                          // 设置场景名称的js接口
    /// BuglyPro.testNativeCrash();                             // 测试Native Crash
    static void registerJSFunctions();
    
    /// 注册js异常捕获，用于自动上报js异常到Bugly“错误”分类下
    static void registerJSExceptionHandler();
    
    /// C++层上报JS异常接口，一般用不上
    static void reportJSError(const char *location, const char *message, const char *stack);
};

#endif /* __BUGLY_JS_AGENT_CREATOR_H__ */
