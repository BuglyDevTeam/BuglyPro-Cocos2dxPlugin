//
//  BuglyJSAgentCreator.cpp
//  Bugly
//
//  Copyright © 2025年 Bugly. All rights reserved.
//
//

#include "BuglyJSAgentCreator.h"

#include "cocos/bindings/jswrapper/SeApi.h"
#include "bindings/sebind/sebind.h"

#include <string.h>
#include <functional>

#include "../CrashReport.h"

#ifndef CATEGORY_JS_EXCEPTION
#define CATEGORY_JS_EXCEPTION 5
#endif

SE_DECLARE_FUNC(js_bugly_pro_set_userid);
SE_DECLARE_FUNC(js_bugly_pro_add_user_value);
SE_DECLARE_FUNC(js_bugly_pro_set_app_channel);
SE_DECLARE_FUNC(js_bugly_pro_set_app_version);
SE_DECLARE_FUNC(js_bugly_pro_set_device_id);
SE_DECLARE_FUNC(js_bugly_pro_set_scene);
SE_DECLARE_FUNC(js_bugly_pro_test_native_crash);


static bool js_bugly_pro_set_userid(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc != 1) {
        SE_REPORT_ERROR("wrong number of arguments: %d, was expecting 1", (int)argc);
        return false;
    }
    
    std::string user_id;
    ok &= sevalue_to_native(args[0], &user_id, nullptr);
    SE_PRECONDITION2(ok, false, "js_bugly_pro_set_userid : Error processing arguments");
    
    CrashReport::setUserId(user_id.c_str());
    return true;
}
SE_BIND_FUNC(js_bugly_pro_set_userid);

static bool js_bugly_pro_add_user_value(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc != 2) {
        SE_REPORT_ERROR("wrong number of arguments: %d, was expecting 2", (int)argc);
        return false;
    }
    
    std::string key, value;
    ok &= sevalue_to_native(args[0], &key, nullptr);
    ok &= sevalue_to_native(args[1], &value, nullptr);
    SE_PRECONDITION2(ok, false, "js_bugly_pro_add_user_value : Error processing arguments");
    
    CrashReport::addUserValue(key.c_str(), value.c_str());
    return true;

}
SE_BIND_FUNC(js_bugly_pro_add_user_value);

static bool js_bugly_pro_set_app_channel(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc != 1) {
        SE_REPORT_ERROR("wrong number of arguments: %d, was expecting 1", (int)argc);
        return false;
    }
    
    std::string app_channel;
    ok &= sevalue_to_native(args[0], &app_channel, nullptr);
    SE_PRECONDITION2(ok, false, "js_bugly_pro_set_app_channel : Error processing arguments");
    
    CrashReport::setAppChannel(app_channel.c_str());
    return true;
}
SE_BIND_FUNC(js_bugly_pro_set_app_channel);

static bool js_bugly_pro_set_device_id(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc != 1) {
        SE_REPORT_ERROR("wrong number of arguments: %d, was expecting 1", (int)argc);
        return false;
    }
    
    std::string device_id;
    ok &= sevalue_to_native(args[0], &device_id, nullptr);
    SE_PRECONDITION2(ok, false, "js_bugly_pro_set_device_id : Error processing arguments");
    
    CrashReport::setDeviceId(device_id.c_str());
    return true;
}
SE_BIND_FUNC(js_bugly_pro_set_device_id);

static bool js_bugly_pro_set_app_version(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc != 1) {
        SE_REPORT_ERROR("wrong number of arguments: %d, was expecting 1", (int)argc);
        return false;
    }
    
    std::string app_version;
    ok &= sevalue_to_native(args[0], &app_version, nullptr);
    SE_PRECONDITION2(ok, false, "js_bugly_pro_set_app_version : Error processing arguments");
    
    CrashReport::setAppVersion(app_version.c_str());
    return true;
}
SE_BIND_FUNC(js_bugly_pro_set_app_version);

static bool js_bugly_pro_set_scene(se::State& s) {
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc != 1) {
        SE_REPORT_ERROR("wrong number of arguments: %d, was expecting 1", (int)argc);
        return false;
    }
    
    std::string scene;
    ok &= sevalue_to_native(args[0], &scene, nullptr);
    SE_PRECONDITION2(ok, false, "js_bugly_pro_set_userid : Error processing arguments");
    
    CrashReport::setScene(scene.c_str());
    return true;
}
SE_BIND_FUNC(js_bugly_pro_set_scene);

static bool js_bugly_pro_test_native_crash(se::State& s) {
    CrashReport::TestCrash(101);
    return true;
}
SE_BIND_FUNC(js_bugly_pro_test_native_crash);

static bool register_js_functions(se::Object *global) {
    const se::AutoHandleScope scope;
    auto cls = se::Class::create("BuglyPro", global, nullptr, nullptr);
    cls->defineStaticFunction("setUserID", _SE(js_bugly_pro_set_userid));
    cls->defineStaticFunction("addUserValue", _SE(js_bugly_pro_add_user_value));
    cls->defineStaticFunction("setAppChannel", _SE(js_bugly_pro_set_app_channel));
    cls->defineStaticFunction("setAppVersion", _SE(js_bugly_pro_set_app_version));
    cls->defineStaticFunction("setDeviceID", _SE(js_bugly_pro_set_device_id));
    cls->defineStaticFunction("setScene", _SE(js_bugly_pro_set_scene));
    cls->defineStaticFunction("testNativeCrash", _SE(js_bugly_pro_test_native_crash));
    
    cls->install();
    JSBClassType::registerClass<BuglyJSAgentCreator>(cls);
    se::ScriptEngine::getInstance()->clearException();
    return true;
}

void BuglyJSAgentCreator::registerJSFunctions() {
    if (se::ScriptEngine::getInstance() == nullptr) {
        SE_REPORT_ERROR("registerJSFunctions, ScriptEngine is null.");
        return;
    }

    register_js_functions(se::ScriptEngine::getInstance()->getGlobalObject());
}

static void JsErrorHandler(const char *location, const char *message, const char *stack) {
    CrashReport::reportException(CATEGORY_JS_EXCEPTION, "JSError", message, stack);
}
void BuglyJSAgentCreator::registerJSExceptionHandler() {
    if (se::ScriptEngine::getInstance() == nullptr) {
        SE_REPORT_ERROR("registerJSExceptionHandler, ScriptEngine is null.");
        return;
    }
    std::function<void(const char *, const char *, const char *)> handler = JsErrorHandler;
    se::ScriptEngine::getInstance()->setJSExceptionCallback(handler);
}

void BuglyJSAgentCreator::reportJSError(const char *location, const char *message, const char *stack) {
    JsErrorHandler(location, message, stack);
}
