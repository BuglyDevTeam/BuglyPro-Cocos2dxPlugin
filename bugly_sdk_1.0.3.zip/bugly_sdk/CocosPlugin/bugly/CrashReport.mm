
#include "CrashReport.h"

#if CC_ENGINE_COCOA_2D_X
#include "cocos2d.h"
#endif // CC_ENGINE_COCOA_2D_X
#include <string.h>

#define LOG_TAG "CrashReport"

#ifndef GAME_TYPE_COCOS
#define GAME_TYPE_COCOS 1
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

#include <android/log.h>
#include <jni.h>
#if CC_ENGINE_COCOA_2D_X
#include "platform/android/jni/JniHelper.h"
#else
#include "platform/java/jni/JniHelper.h"
#endif // CC_ENGINE_COCOA_2D_X

#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)
#define LOGI(fmt, args...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, fmt, ##args)
#define LOGW(fmt, args...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, fmt, ##args)
#define LOGE(fmt, args...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, fmt, ##args)

#define AGENT_CLASS "com/tencent/bugly/agent/GameAgentPro"
#define METHOD_INIT "initAgent"
#define METHOD_INIT_SIGN "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZI[Ljava/lang/String;)V"
#define METHOD_SET_GAME_TYPE "setGameType"
#define METHOD_SET_GAME_TYPE_SIGN "(I)V"
#define METHOD_UPDATE_UNIQUE_ID "updateUniqueIdAgent"
#define METHOD_UPDATE_UNIQUE_ID_SIGN "(Ljava/lang/String;)V"
#define METHOD_UPDATE_USER_ID "updateUserIdAgent"
#define METHOD_UPDATE_USER_ID_SIGN "(Ljava/lang/String;)V"
#define METHOD_UPDATE_LOG_LEVEL "updateLogLevelAgent"
#define METHOD_UPDATE_LOG_LEVEL_SIGN "(I)V"
#define METHOD_POST_EXCEPTION "postExceptionAgent"
#define METHOD_POST_EXCEPTION_SIGN "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V"
#define METHOD_PUT_USER_DATA "putUserDataAgent"
#define METHOD_PUT_USER_DATA_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"
#define METHOD_SET_ADDITIONAL_ATTACHMENT_PATHS "setAdditionalAttachmentPathsAgent"
#define METHOD_SET_ADDITIONAL_ATTACHMENT_PATHS_SIGN "([Ljava/lang/String;)V"
#define METHOD_LAUNCH_ADD_TAG "launchAddTagAgent"
#define METHOD_LAUNCH_ADD_TAG_SIGN "(Ljava/lang/String;)V"
#define METHOD_LAUNCH_SPAN_START "launchSpanStartAgent"
#define METHOD_LAUNCH_SPAN_START_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"
#define METHOD_LAUNCH_SPAN_END "launchSpanEndAgent"
#define METHOD_LAUNCH_SPAN_END_SIGN "(Ljava/lang/String;)V"
#define METHOD_REPORT_APP_FULL_LAUNCH "reportAppFullLaunchAgent"
#define METHOD_REPORT_APP_FULL_LAUNCH_SIGN "()V"

/// Bugly类的接口
#define BUGLY_CLASS "com/tencent/bugly/library/Bugly"
#define METHOD_ENTER_SCENE_ID "enterScene"
#define METHOD_ENTER_SCENE_ID_SIGN "(Ljava/lang/String;)V"
#define METHOD_TEST_CRASH_ID "testCrash"
#define METHOD_TEST_CRASH_ID_SIGN "(I)V"

/// BuglyCustomLog类的接口
#define BUGLY_CUSTOM_LOG_CLASS "com/tencent/bugly/library/BuglyCustomLog"
#define METHOD_ENTER_LOG_V "v"
#define METHOD_ENTER_LOG_V_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"
#define METHOD_ENTER_LOG_D "d"
#define METHOD_ENTER_LOG_D_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"
#define METHOD_ENTER_LOG_I "i"
#define METHOD_ENTER_LOG_I_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"
#define METHOD_ENTER_LOG_W "w"
#define METHOD_ENTER_LOG_W_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"
#define METHOD_ENTER_LOG_E "e"
#define METHOD_ENTER_LOG_E_SIGN "(Ljava/lang/String;Ljava/lang/String;)V"

// init params
typedef struct {
    char* appVersion;
    char* buildNum;
    char* uniqueId;
    char* userId;
    char* deviceModel;
    char* appVersionType;
    char* appChannel;
    int logLevel;
} InitParams;

InitParams initParams;

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    #import <Foundation/Foundation.h>

    #define NSStringMake(const_char_pointer) (const_char_pointer == NULL ? nil : @(const_char_pointer))
    #define NSStringMakeNonnull(const_char_pointer) (const_char_pointer == NULL ? @"" : @(const_char_pointer))

#if CC_ENGINE_COCOA_2D_X
    #define LOGD(fmt, args...) CCLOG("[Debug] %s: " fmt, LOG_TAG, ##args)
    #define LOGI(fmt, args...) CCLOG("[Info] %s: " fmt, LOG_TAG, ##args)
    #define LOGW(fmt, args...) CCLOGERROR("[Warn] %s: " fmt, LOG_TAG, ##args)
    #define LOGE(fmt, args...) CCLOGERROR("[Error] %s: " fmt, LOG_TAG, ##args)
#else
    #define LOGD(fmt, args...) printf("[Debug] %s: " fmt, LOG_TAG, ##args)
    #define LOGI(fmt, args...) printf("[Info] %s: " fmt, LOG_TAG, ##args)
    #define LOGW(fmt, args...) printf("[Warn] %s: " fmt, LOG_TAG, ##args)
    #define LOGE(fmt, args...) printf("[Error] %s: " fmt, LOG_TAG, ##args)
#endif //CC_ENGINE_COCOA_2D_X

    #define BUGLY_AGENT_CLASS @"BuglyAgent"
    #define BUGLY_AGENT_METHOD_INIT_MODULES @"setBuglyAgentV2PluginArray:"
    #define BUGLY_AGENT_METHOD_SET_CRASH_CALLBACK @"setBuglyAgentV2CrashCallback:"
    #define BUGLY_AGENT_METHOD_INIT_LOG @"initWithAppId:appKey:debugMode:logger:"
    #define BUGLY_AGENT_METHOD_USER @"setUserIdentifier:"
    #define BUGLY_AGENT_METHOD_CHANNEL @"setAppChannel:"
    #define BUGLY_AGENT_METHOD_DEVICEID @"setDeviceIdentifier:"
    #define BUGLY_AGENT_METHOD_VERSION @"setAppVersion:"
    #define BUGLY_AGENT_METHOD_EXCEPTION @"reportException:name:message:stackTrace:userInfo:terminateApp:"
    #define BUGLY_AGENT_METHOD_SCENE @"setSceneTag:"
    #define BUGLY_AGENT_METHOD_SCENE_VALUE @"setSceneValue:forKey:"
	#define BUGLY_AGENT_METHOD_SCENE_CLEAN @"removeSceneValueForKey:"
    #define BUGLY_AGENT_METHOD_LOG @"level:tag:log:"
    #define BUGLY_AGENT_METHOD_LOGGER @"log:tag:file:func:line:msg:"
    #define BUGLY_AGENT_METHOD_LOGGER_FLUSH_LOG @"flushLog"
    #define BUGLY_AGENT_METHOD_CONFIG_REPORTER_TYPE @"configCrashReporterType:"

    #define kBuglyModuleNames @[@"BuglyCrashMonitorPlugin"]
#endif

CrashReport::CrashReport(){
    LOGD("%s", __FUNCTION__);
}

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

bool CrashReport::checkPendingException(JNIEnv* env) {
    if (env == NULL) {
        return false;
    }

    if (env->ExceptionOccurred() != 0) {
        LOGE("[cocos2d-x] check jni error");
        env->ExceptionDescribe();
        env->ExceptionClear();
        return true;
    }
    return false;
}

#if CC_ENGINE_COCOA_2D_X
JNIEnv* CrashReport::getJniEnv() {
    JavaVM* jvm = cocos2d::JniHelper::getJavaVM();
    if (jvm == NULL) {
        LOGE("[cocos2d-x] JavaVM is null.");
        return NULL;
    }
    JNIEnv* env = NULL;
    jvm->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (env == NULL) {
        LOGE("[cocos2d-x] failed to get env.");
        return NULL;
    }
    return env;
}
#else
JNIEnv* CrashReport::getJniEnv() {
    return cc::JniHelper::getEnv();
}
#endif //CC_ENGINE_COCOA_2D_X

jstring CrashReport::getJniString(JNIEnv* jniEnv, const char* str) {
    if (str == NULL) {
        return NULL;
    }

    JNIEnv *env = jniEnv;
    if (env == NULL) {
        env = getJniEnv();
    }
    if (env == NULL) {
        return NULL;
    }
    jstring jniString = env->NewStringUTF(str);
    if (checkPendingException(env)) {
        LOGE("[cocos2d-x] failed to new Java UTF string: %s", str);
        return NULL;
    }
    return jniString;
}

void CrashReport::releaseJniString(JNIEnv* jniEnv, jstring jniString) {
    if (jniString == NULL) {
        return;
    }

    JNIEnv *env = jniEnv;
    if (env == NULL) {
        env = getJniEnv();
    }
    if (env == NULL) {
        return;
    }
    env->DeleteLocalRef(jniString);
}

bool CrashReport::callJniStaticVoidMethod(JNIEnv* jniEnv, const char* className, const char* methodName, const char* paramType, ...) {
    if (className == NULL || methodName == NULL || paramType == NULL) {
		LOGE("[cocos2d-x] parameters input to callJniStaticVoidMethod is not enough.");
        return false;
    }
   
#if CC_ENGINE_COCOA_2D_X   
    JNIEnv *env = jniEnv;
    if (env == NULL) {
        env = getJniEnv();
    }
	if (env == NULL) {
		LOGE("[cocos2d-x] can not get JNIEnv.");
		return false;
	}
    jclass jniClass = env->FindClass(className);
    if (jniClass == NULL || checkPendingException(env)) {
        LOGE("[cocos2d-x] failed to find class: %s", className);
        return false;
    }

    jmethodID method = env->GetStaticMethodID(jniClass, methodName, paramType);
    if (method == NULL || checkPendingException(env)) {
        LOGE("[cocos2d-x] failed to find method '%s' with param type '%s'.", methodName, paramType);
        env->DeleteLocalRef(jniClass); // 释放本地引用
        return false;
    }
#else
    cc::JniMethodInfo t;
    if (!cc::JniHelper::getStaticMethodInfo(t, className, methodName, paramType)) {
        LOGE("[cocos2d-x] can not getStaticMethodInfo, class:%s, method:%s", className, methodName);
        return false;
    }
    
    JNIEnv *env = t.env;
    jclass jniClass = t.classID;
    jmethodID method = t.methodID;
#endif //CC_ENGINE_COCOA_2D_X

    va_list args;
    va_start(args, paramType);
    LOGI("[cocos2d-x] trying to call method: %s", methodName);
    env->CallStaticVoidMethodV(jniClass, method, args);
    va_end(args);

    if (checkPendingException(env)) {
        LOGE("[cocos2d-x] failed to call method: %s", methodName);
        env->DeleteLocalRef(jniClass); // 释放本地引用
        return false;
    }

    env->DeleteLocalRef(jniClass); // 释放本地引用
    return true;
}

void CrashReport::configCrashReportParams(const char* appVersion, const char* buildNum, const char* uniqueId,
                                          const char* userId, const char* deviceModel, const char* appVersionType,
                                          int logLevel, const char* appChannel) {
    LOGI("[cocos2d-x] set init params.");
    if (initParams.appVersion) {
        free(initParams.appVersion);
        initParams.appVersion = nullptr;
    }
    if (initParams.buildNum) {
        free(initParams.buildNum);
        initParams.buildNum = nullptr;
    }
    if (initParams.uniqueId) {
        free(initParams.uniqueId);
        initParams.uniqueId = nullptr;
    }
    if (initParams.userId) {
        free(initParams.userId);
        initParams.userId = nullptr;
    }
    if (initParams.deviceModel) {
        free(initParams.deviceModel);
        initParams.deviceModel = nullptr;
    }
    if (initParams.appVersionType) {
        free(initParams.appVersionType);
        initParams.appVersionType = nullptr;
    }
    if (initParams.appChannel) {
        free(initParams.appChannel);
        initParams.appChannel = nullptr;
    }

    initParams.appVersion = strdup(appVersion);
    initParams.buildNum = strdup(buildNum);
    initParams.uniqueId = strdup(uniqueId);
    initParams.userId = strdup(userId);
    initParams.deviceModel = strdup(deviceModel);
    initParams.appVersionType = strdup(appVersionType);
    initParams.logLevel = logLevel;

    if (appChannel) {
        initParams.appChannel = strdup(appChannel);
    } 
}

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
static void logger_func(int level, const char *log) {
    NSLog(@"%s", log);
//    DDLogVerbose(@"%@", [NSString stringWithUTF8String:log]);
}
#endif

void CrashReport::initCrashReport(const char* appId, const char* appKey) {
    CrashReport::initCrashReport(appId, appKey, false);
}

void CrashReport::initCrashReport(const char* appId, const char* appKey, bool isDebug) {
    CrashReport::initCrashReport(appId, appKey, isDebug, CrashReport::LogLevel::Off);
}

bool CrashReport::initialized = false;
bool CrashReport::hasSetGameType = false;
int CrashReport::crashReporterType = 0;

void CrashReport::initCrashReport(const char* appId, const char* appKey, bool isDebug, CrashReport::LogLevel level) {
	if (!initialized) {
		#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
			LOGI("[cocos2d-x] start init.");
			initialized = true;
#if CC_ENGINE_COCOA_2D_X  			
			JavaVM* jvm = cocos2d::JniHelper::getJavaVM();
			if (jvm == NULL) {
				LOGE("[cocos2d-x] JavaVM is null.");
				return;
			}
			JNIEnv* env = NULL;
			jvm->GetEnv((void**)&env, JNI_VERSION_1_6);
			if (env == NULL) {
				LOGE("[cocos2d-x] JNIEnv is null.");
				return;
			}
			jvm->AttachCurrentThread(&env, 0);
#else
			JNIEnv* env = getJniEnv();
#endif //CC_ENGINE_COCOA_2D_X

            // set game type
            setGameType();

			// appChannel
            jstring jAppChannel = nullptr;
            if (crashReporterType != 0) {
                LOGI("[cocos2d-x] set channel: %d", crashReporterType);
                const char* packageName = "";
                switch(crashReporterType) {
                    case 0:
                    case 1:
                        break;
                    case 2:
                        packageName = "com.tencent.bugly.msdk";
                        break;
                    case 3:
                        packageName = "com.tencent.bugly.imsdk";
                        break;
                    default:
                        break;
                }
                LOGI("set packagename: %s", packageName);
                jAppChannel = getJniString(env, packageName);
            }

            /// 如果业务主动设置了appChannel,那么强制用业务设置的
            if (initParams.appChannel) {
                releaseJniString(env, jAppChannel);
                jAppChannel = getJniString(env, initParams.appChannel);
            }

            // init params
            jstring jAppId = getJniString(env, appId);
            jstring jAppKey = getJniString(env, appKey);
            jstring jAppVersion = getJniString(env, initParams.appVersion);
            jstring jBuildNum = getJniString(env, initParams.buildNum);
            jstring jUniqueId = getJniString(env, initParams.uniqueId);
            jstring jUserId = getJniString(env, initParams.userId);
            jstring jDeviceModel = getJniString(env, initParams.deviceModel);
            jstring jAppVersionType = getJniString(env, initParams.appVersionType);

			// call init
			LOGI("[cocos2d-x] init Bugly by game agent.");

            callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_INIT, METHOD_INIT_SIGN,
                                    jAppId, jAppKey, jAppVersion, jBuildNum, jUniqueId, jUserId,
                                    jDeviceModel, jAppVersionType, jAppChannel, isDebug,
                                    initParams.logLevel, nullptr);

            releaseJniString(env, jAppId);
            releaseJniString(env, jAppKey);
            releaseJniString(env, jAppVersion);
            releaseJniString(env, jBuildNum);
            releaseJniString(env, jUniqueId);
            releaseJniString(env, jUserId);
            releaseJniString(env, jDeviceModel);
            releaseJniString(env, jAppVersionType);
            releaseJniString(env, jAppChannel);
        // iOS
		#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
        	NSString* pAppId = NSStringMake(appId);
            NSString* pAppKey = NSStringMake(appKey);
            BOOL pDebug = isDebug ? YES : NO;
        
        Class classObject = NSClassFromString(@"Bugly");
        [classObject performSelector:@selector(registerLogCallback:) withObject:(id)logger_func];
        
			Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
            if (clazz) {
                BOOL initLog = false;
                SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_INIT_LOG);
                
                NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
                if (signature) {
                    
                    LOGI("Init the sdk with App ID: %s, App Key: %s", appId, appKey);
                    
                    NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
                    if (invocation) {
                        [invocation setTarget:clazz];
                        [invocation setSelector:selector];
                        
                        [invocation setArgument:&pAppId atIndex:2];
                        [invocation setArgument:&pAppKey atIndex:3];
                        [invocation setArgument:&pDebug atIndex:4];
                        
                        if (initLog) {
                            //Error=4,Warn=3,Info=2,Debug=1,Verbose=0,Off=-1
                            //LogError=1<<0,Warn=1<<1,Info=1<<2,Debug=1<<3,Verbose=1<<4
                            NSInteger pLevel = level;
                            
                            [invocation setArgument:&pLevel atIndex:5];
                        }
                        
                        [invocation invoke];
                    }
                }
            } else {
                LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
            }
        #endif /* iOS */
            initialized = true;
		}
    
}

void CrashReport::addUserValue(const char* key, const char* value) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	LOGI("[cocos2d-x] put user data: %s:%s", key, value);
    JNIEnv* env = getJniEnv();
    
    jstring jKey = getJniString(env, key);
    jstring jValue = getJniString(env, value);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_PUT_USER_DATA, METHOD_PUT_USER_DATA_SIGN, jKey, jValue);
    releaseJniString(env, jKey);
    releaseJniString(env, jValue);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	NSString * pKey = NSStringMakeNonnull(key);
	NSString * pValue = NSStringMakeNonnull(value);
    
	Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_SCENE_VALUE);
        
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        
        if (signature) {
            LOGI("Set user Key-Value: [%s, %s]", key, value);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pValue atIndex:2];
                [invocation setArgument:&pKey atIndex:3];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::setScene(const char* scene) {
    setGameType();
    if (!scene) return ;
    
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    JNIEnv* env = getJniEnv();
    jstring jScene = getJniString(env, scene);
    callJniStaticVoidMethod(env, BUGLY_CLASS, METHOD_ENTER_SCENE_ID, METHOD_ENTER_SCENE_ID_SIGN, jScene);
    releaseJniString(env, jScene);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    NSString * pScene = NSStringMakeNonnull(scene);
    
    Class clazz = NSClassFromString(@"Bugly");
    if (clazz) {
        SEL selector = NSSelectorFromString(@"setScene:");
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        
        if (signature) {
            LOGI("Set Scene: %s", scene);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pScene atIndex:2];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(Bugly)");
    }
#endif
}

void CrashReport::setUserId(const char* userId) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] set user ID: %s", userId);
    
    JNIEnv* env = getJniEnv();
    
    jstring jUserId = getJniString(env, userId);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_UPDATE_USER_ID,
                            METHOD_UPDATE_USER_ID_SIGN, jUserId);
    releaseJniString(env, jUserId);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	NSString * pUserId = NSStringMake(userId);
	
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_USER);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        if (signature) {
            LOGI("Set user id: %s", userId);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pUserId atIndex:2];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::reportException(int category, const char* type, const char* msg, const char* traceback) {
    reportException(category, type, msg, traceback, false);
}

void CrashReport::reportException(int category, const char* type, const char* msg, const char* traceback, bool quit) {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] post a exception.");
    JNIEnv* env = getJniEnv();
    
	jstring typeStr = getJniString(env, type);
	jstring msgStr = getJniString(env, msg);
	jstring traceStr = getJniString(env, traceback);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_POST_EXCEPTION, METHOD_POST_EXCEPTION_SIGN,
                            category, typeStr, msgStr, traceStr, quit);
    releaseJniString(env, typeStr);
    releaseJniString(env, msgStr);
    releaseJniString(env, traceStr);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	NSUInteger pCategory = category;
	NSString * pType = NSStringMake(type);
	NSString * pMsg = NSStringMake(msg);
	NSString * pTraceStack = NSStringMake(traceback);
    NSDictionary * nullObject = nil;
    BOOL terminateApp = quit ? YES : NO;

	Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_EXCEPTION);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        
        if (signature) {
            LOGI("Report exception: %s\n%s", msg, traceback);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pCategory atIndex:2];
                [invocation setArgument:&pType atIndex:3];
                [invocation setArgument:&pMsg atIndex:4];
                [invocation setArgument:&pTraceStack atIndex:5];
                [invocation setArgument:&nullObject atIndex:6];
                [invocation setArgument:&terminateApp atIndex:7];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::setAppChannel(const char * channel){
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] please set app channel before init.");
    // do nothing
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    NSString * pChannel = NSStringMake(channel);
    
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_CHANNEL);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        if (signature) {
            LOGI("Set channel: %s", channel);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pChannel atIndex:2];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::setAppVersion(const char * version){
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] please set app version before init.");
    // do nothing
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    NSString * pVersion = NSStringMake(version);
    
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_VERSION);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        if (signature) {
            LOGI("Set version: %s", version);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pVersion atIndex:2];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::setGameType(){
    if (hasSetGameType) {
        return;
    }
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    if (callJniStaticVoidMethod(nullptr, AGENT_CLASS, METHOD_SET_GAME_TYPE, METHOD_SET_GAME_TYPE_SIGN, GAME_TYPE_COCOS)) {
        hasSetGameType = true;
    }

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::setCrashReporterType(int type) {
    crashReporterType = type;
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    // Android
    LOGD("Set the crash reporter type: %d", type);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    //  iOS
    NSInteger pType = type;
    
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_CONFIG_REPORTER_TYPE);
        
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        
        if (signature) {
            LOGI("Config crash reporter type: %d", type);
    
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pType atIndex:2];
                
                [invocation invoke];
            } else {
                LOGE("Fail to invocationWithMethodSignature for selector %s", BUGLY_AGENT_METHOD_CONFIG_REPORTER_TYPE.UTF8String);
            }
        } else {
            LOGE("Fail to methodSignatureForSelector %s", BUGLY_AGENT_METHOD_CONFIG_REPORTER_TYPE.UTF8String);
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
    
#endif
}

void CrashReport::setDeviceId(const char* deviceId) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] set device ID: %s", deviceId);

    JNIEnv* env = getJniEnv();

    jstring jDeviceId = getJniString(env, deviceId);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_UPDATE_UNIQUE_ID,
                            METHOD_UPDATE_UNIQUE_ID_SIGN, jDeviceId);
    releaseJniString(env, jDeviceId);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    NSString * pDeviceId = NSStringMake(deviceId);
    
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_DEVICEID);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        if (signature) {
            LOGI("Set deviceid: %s", deviceId);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pDeviceId atIndex:2];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::setLogLevel(int logLevel) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] set log level: %d", logLevel);

    JNIEnv* env = getJniEnv();

    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_UPDATE_LOG_LEVEL, METHOD_UPDATE_LOG_LEVEL_SIGN, logLevel);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::setAdditionalAttachmentPaths(const char* filePaths[], size_t fileNum) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] set additional attachment paths.");

    JNIEnv* env = getJniEnv();
    if (env == nullptr) {
        LOGE("[cocos2d-x] Failed to get JNI environment.");
        return;
    }

    jclass stringClass = env->FindClass("java/lang/String");
    if (stringClass == nullptr) {
        LOGE("[cocos2d-x] Failed to find java/lang/String class.");
        return;
    }

    jobjectArray stringArray = env->NewObjectArray(static_cast<jsize>(fileNum), stringClass, nullptr);
    if (stringArray == nullptr) {
        LOGE("[cocos2d-x] Failed to create new object array.");
        env->DeleteLocalRef(stringClass);
        return;
    }

    // Fill the string array
    for (jsize i = 0; i < static_cast<jsize>(fileNum); ++i) {
        jstring path = env->NewStringUTF(filePaths[i]);
        if (path == nullptr) {
            LOGE("[cocos2d-x] Failed to create new string for path: %s", filePaths[i]);
            continue;
        }
        env->SetObjectArrayElement(stringArray, i, path);
        env->DeleteLocalRef(path);
    }

    // Call Method
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_SET_ADDITIONAL_ATTACHMENT_PATHS,
                            METHOD_SET_ADDITIONAL_ATTACHMENT_PATHS_SIGN, stringArray);

    env->DeleteLocalRef(stringArray);
    env->DeleteLocalRef(stringClass);

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::launchAddTag(const char* tag) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] launch add tag: %s", tag);

    JNIEnv* env = getJniEnv();

    jstring jTag = getJniString(env, tag);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_LAUNCH_ADD_TAG,
                            METHOD_LAUNCH_ADD_TAG_SIGN, jTag);
    releaseJniString(env, jTag);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::launchSpanStart(const char* spanName, const char* parentSpanName) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] launch span start, span name: %s, parent span name: %s", spanName, parentSpanName);

    JNIEnv* env = getJniEnv();

    jstring jSpanName = getJniString(env, spanName);
    jstring jParentSpanName = getJniString(env, parentSpanName);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_LAUNCH_SPAN_START,
                            METHOD_LAUNCH_SPAN_START_SIGN, jSpanName, jParentSpanName);
    releaseJniString(env, jSpanName);
    releaseJniString(env, jParentSpanName);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::launchSpanEnd(const char* spanName) {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    LOGI("[cocos2d-x] launch span end tag: %s", spanName);

    JNIEnv* env = getJniEnv();

    jstring jSpanName = getJniString(env, spanName);
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_LAUNCH_SPAN_END,
                            METHOD_LAUNCH_SPAN_END_SIGN, jSpanName);
    releaseJniString(env, jSpanName);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::reportAppFullLaunch() {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    JNIEnv* env = getJniEnv();
    callJniStaticVoidMethod(env, AGENT_CLASS, METHOD_REPORT_APP_FULL_LAUNCH,
                            METHOD_REPORT_APP_FULL_LAUNCH_SIGN);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#endif
}

void CrashReport::TestCrash(int crashType) {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    JNIEnv* env = getJniEnv();
    callJniStaticVoidMethod(env, BUGLY_CLASS, METHOD_TEST_CRASH_ID,
                            METHOD_TEST_CRASH_ID_SIGN, crashType);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    if (crashType == 101) {
        int *a = (int *)0x1234;
        *a = 1;
    }
#endif
}

//typedef NS_ENUM(NSInteger, BuglyLogLevel) {
//    BuglyLogLevelAll = 0,
//    BuglyLogLevelVerbose = 0,
//    BuglyLogLevelDebug,
//    BuglyLogLevelInfo,
//    BuglyLogLevelWarn,
//    BuglyLogLevelError,
//    BuglyLogLevelFatal,
//    BuglyLogLevelNone,
//};

//enum class CRLogLevel{ Off=0, Error=1,Warning=2,Info=3,Debug=4,Verbose=5 };
static int BuglyLoggerLevelFromCRLogLevel(CrashReport::CRLogLevel level) {
    static const int s_BuglyLoggerLevels[] = {6, 4, 3, 2, 1, 0};
    int l = (int)level;
    if (l < 0 || l >= 6) {
        return 6;
    }
    
    return s_BuglyLoggerLevels[l];
}

#define LOG_BUFFER_SIZE 1024
void CrashReport::logBuffer(CrashReport::CRLogLevel level, const char* tag, const char* fmts, ...) {
    if (level == CrashReport::CRLogLevel::Off) {
        return;
    }
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    // static char msg[LOG_BUFFER_SIZE];
    // va_list args;
    // va_start(args, fmts);
    // int size = vsnprintf(msg, LOG_BUFFER_SIZE, fmts, args);
    // va_end(args);
    // if (size > LOG_BUFFER_SIZE) {
    //     LOGW("The length[%d] of string is out of the buffer size[%d]", size, LOG_BUFFER_SIZE);
    // }
    
    // JNIEnv* env = getJniEnv();
    // jstring jTag = getJniString(env, tag);
    // jstring jMsg = getJniString(env, msg);
    
    // const char* logger_method_id = nullptr;
    // const char* logger_method_sign = nullptr;
    // switch (level) {
    //     case CrashReport::CRLogLevel::Error:
    //     {
    //         logger_method_id = METHOD_ENTER_LOG_E;
    //         logger_method_sign = METHOD_ENTER_LOG_E_SIGN;
    //     }
    //         break;
    //     case CrashReport::CRLogLevel::Warning:
    //     {
    //         logger_method_id = METHOD_ENTER_LOG_W;
    //         logger_method_sign = METHOD_ENTER_LOG_W_SIGN;
    //     }
    //     case CrashReport::CRLogLevel::Info:
    //     {
    //         logger_method_id = METHOD_ENTER_LOG_I;
    //         logger_method_sign = METHOD_ENTER_LOG_I_SIGN;
    //     }
    //     case CrashReport::CRLogLevel::Debug:
    //     {
    //         logger_method_id = METHOD_ENTER_LOG_D;
    //         logger_method_sign = METHOD_ENTER_LOG_D_SIGN;
    //     }
    //     case CrashReport::CRLogLevel::Verbose:
    //     {
    //         logger_method_id = METHOD_ENTER_LOG_V;
    //         logger_method_sign = METHOD_ENTER_LOG_V_SIGN;
    //     }
    // }
    
    // if (logger_method_id == nullptr || logger_method_sign == nullptr) {
    //     return ;
    // }
    // callJniStaticVoidMethod(env, BUGLY_CUSTOM_LOG_CLASS, logger_method_id, logger_method_sign, jTag, jMsg);
    // releaseJniString(env, jTag);
    // releaseJniString(env, jMsg);
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    if (NULL == fmts) {
        return;
    }

    static char msg[LOG_BUFFER_SIZE];
    va_list args;
    
    va_start(args, fmts);
    int size = vsnprintf(msg, LOG_BUFFER_SIZE, fmts, args);
    va_end(args);
    
    if (size > LOG_BUFFER_SIZE) {
        LOGW("The length[%d] of string is out of the buffer size[%d]", size, LOG_BUFFER_SIZE);
    }
    
    // CCLOG("[LOG] %s: %s", tag, msg);
    
    NSString * pMsg = NSStringMake(msg);
    NSString * pTag = NSStringMake(tag);
    
    if (pMsg == nil) {
        return;
    }
    //Error=4,Warn=3,Info=2,Debug=1,Verbose=0,Off=-1
    //LogError=1<<0,Warn=1<<1,Info=1<<2,Debug=1<<3,Verbose=1<<4
//    NSInteger pLevel = (level >= 4 ? 1 : (level == 3 ? 2 : (level == 2 ? 4 : (level == 1 ? 8 : (level == 0 ? 16 : 0)))));
    NSInteger pLevel = BuglyLoggerLevelFromCRLogLevel(level);
    
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_LOGGER);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        
        if (signature) {
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            
            NSString * file = nil;
            NSString * func = nil;
            NSInteger line = 0;
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pLevel atIndex:2];
                [invocation setArgument:&pTag atIndex:3];
                [invocation setArgument:&file atIndex:4];
                [invocation setArgument:&func atIndex:5];
                [invocation setArgument:&line atIndex:6];
                [invocation setArgument:&pMsg atIndex:7];
                
                [invocation invoke];
            }
        } else {
            LOGE("Fail to methodSignatureForSelector %s", BUGLY_AGENT_METHOD_LOG.UTF8String);
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::flushLog() {
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_LOGGER_FLUSH_LOG);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        if (signature) {
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation invoke];
            }
        }
    }
    else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}

void CrashReport::setBuglyPluginArray(int count, const char** plugins) {
    if (count == 0 || plugins == nullptr) {
        return ;
    }
    
    setGameType();
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    
    NSMutableArray<NSString*>* pluginsArray = [NSMutableArray<NSString*> new];
    for (int i = 0; i < count; i++) {
        [pluginsArray addObject:NSStringMake(plugins[i])];
    }
    
    Class clazz = NSClassFromString(BUGLY_AGENT_CLASS);
    
    if (clazz) {
        SEL selector = NSSelectorFromString(BUGLY_AGENT_METHOD_INIT_MODULES);
        NSMethodSignature* signature = [clazz methodSignatureForSelector:selector];
        if (signature) {
            LOGI("Set pluginsArray: %s", pluginsArray.description.UTF8String);
            
            NSInvocation* invocation = [NSInvocation invocationWithMethodSignature:signature];
            if (invocation) {
                [invocation setTarget:clazz];
                [invocation setSelector:selector];
                
                [invocation setArgument:&pluginsArray atIndex:2];
                
                [invocation invoke];
            }
        }
    } else {
        LOGE("Fail to get class by NSClassFromString(%s)", BUGLY_AGENT_CLASS.UTF8String);
    }
#endif
}
