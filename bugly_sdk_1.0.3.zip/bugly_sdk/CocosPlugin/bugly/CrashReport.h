/******************************************************
 Copyright (C) 2024 Tencent Bugly, Inc.
 
 https://bugly.tds.qq.com
 
 
 Version: 2.0.0
 
 ******************************************************/

#ifndef CRASHREPORT_H
#define CRASHREPORT_H

#ifndef CATEGORY_LUA_EXCEPTION
#define CATEGORY_LUA_EXCEPTION 6
#endif

#ifndef CATEGORY_JS_EXCEPTION
#define CATEGORY_JS_EXCEPTION 5
#endif

#if defined (CC_PLATFORM)
#define CC_TARGET_PLATFORM CC_PLATFORM
#define CC_ENGINE_COCOA_CREATOR		1
#else
#define CC_ENGINE_COCOA_2D_X		1
#endif

#if CC_ENGINE_COCOA_2D_X
#include "cocos2d.h"
#else
#include <cstddef>
#endif //CC_ENGINE_COCOA_2D_X

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	#include <jni.h>

    // app version type
    #define APP_VERSION_TYPE_UNKNOWN "Unknown"
    #define APP_VERSION_TYPE_DEBUG "Debug"
    #define APP_VERSION_TYPE_GARY "Gray"
    #define APP_VERSION_TYPE_RELEASE "Release"
#endif

class CrashReport
{
public:
    /**
     * 日志级别
     */
    enum LogLevel { Off=0, Error=1,Warning=2,Info=3,Debug=4,Verbose=5 };

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
    /**
     *    @brief 检查JNI调用是否存在Pending exception
     *
     *    @param env
     */
    static bool checkPendingException(JNIEnv* env);

    static JNIEnv* getJniEnv();

    static jstring getJniString(JNIEnv* env, const char* str);

    static void releaseJniString(JNIEnv* env, jstring jniString);

    static bool callJniStaticVoidMethod(JNIEnv* env, const char* className, const char* methodName, const char* paramType, ...);

    /**
     * 初始化参数配置
     * @param appVersion app版本
     * @param buildNum 构建号
     * @param uniqueId 设备唯一ID
     * @param userId 用户ID
     * @param deviceModel 设备类型
     * @param appVersionType app版本类型，使用APP_VERSION_TYPE_宏
     * @param logLevel 性能日志等级打印，值参考LogLevel枚举类
     * @param appChannel 渠道信息
     */
    static void configCrashReportParams(const char* appVersion, const char* buildNum, const char* uniqueId,
                                        const char* userId, const char* deviceModel, const char* appVersionType,
                                        int logLevel, const char* appChannel = nullptr);
#endif

    /**
     *    @brief 初始化
     *
     *    @param appId 注册应用时，Bugly分配的AppID
     *    @param appId 注册应用时，Bugly分配的AppKey
     */
    static void initCrashReport(const char* appId, const char* appKey);
    
    /**
     *    @brief 初始化
     *
     *    @param appId 注册应用时，Bugly分配的AppID
     *    @param appId 注册应用时，Bugly分配的AppKey
     *    @param debug 是否开启Debug信息打印，默认关闭，开启则会打印SDK的调试信息
     */
	static void initCrashReport(const char* appId, const char* appKey, bool debug);

    /**
 *    @brief 初始化
 *
 *    @param appId 注册应用时，Bugly分配的AppID
 *    @param appId 注册应用时，Bugly分配的AppKey
 *    @param debug 是否开启Debug信息打印，默认关闭，开启则会打印SDK的调试信息
 *    @param level 是否开启崩溃时自定义日志的上报，默认值为 {@link CRLogLevel:Off}，即关闭。设置为其他的值，即会在崩溃时上报自定义日志。如设置为CRLogLevel:Warning，则会上报CRLogLevel:Warning、CRLogLevel:Error的日志
 */
    static void initCrashReport(const char* appId, const char* appKey, bool debug, CrashReport::LogLevel level);
    
    /**
     *    @brief 设置/更新应用的用户唯一标识
     *
     *    @param userId
     */
    static void setUserId(const char* userId);
    
    /**
     *    @brief 上报自定义错误
     *
     *    @param category  错误的分类，5表示Lua错误，6表示JS错误
     *    @param type      错误类型的名称
     *    @param msg       错误原因
     *    @param traceback 错误堆栈
     */
	static void reportException(int category, const char* type, const char* msg, const char* traceback);
    
    static void reportException(int category, const char* type, const char* msg, const char* traceback, bool quit);
	
    /**
     *    @brief 设置自定义Key-Value
     *
     *    @param key
     *    @param value
     */
    static void addUserValue(const char* key, const char* value);
    
	/**
     *    @brief 设置场景信息，会在页面的"现场数据"->"页面跟踪"中显示，也会在问题的"场景"字段中显示
     */
    static void setScene(const char* scene);
    
    /**
     *    @brief 设置渠道，Android平台请在configCrashReportParams中设置
     *
     *    @param channel 渠道标识
     */
    static void setAppChannel(const char* channel);
    
    /**
     *    @brief 设置应用版本，Android平台请在configCrashReportParams中设置
     *
     *    @param version 应用版本信息
     */
    static void setAppVersion(const char* version);
    
    /**
     *    @brief 设置CrashReporter的渠道类别，默认值为0，表示官方版本，2表示MSDK内置版本，3表示IM SDK内置版本
     *
     *    @param type
     */
    static void setCrashReporterType(int type);

    /**
     *    @brief 设置游戏类型，Cocos为1
     */
    static void setGameType();

    /**
     * 设置/更新设备唯一ID
     * @param deviceId 设备唯一ID
     */
    static void setDeviceId(const char* deviceId);

    /**
     * 设置异常自定义附件关联上报
     * @param filePaths 附件路径
     * @param fileNum 附件数量
     */
    static void setAdditionalAttachmentPaths(const char* filePaths[], size_t fileNum);

    /**
     * [性能] 设置日志等级
     * @param logLevel 取值[LogLevel]
     */
    static void setLogLevel(int logLevel);

    /**
     * [性能] 设置启动自定义标签
     * @param tag
     */
    static void launchAddTag(const char* tag);


    /**
     * [性能] 设置启动Span开始打点
     * @param spanName span名称
     * @param parentSpanName 父span名称
     */
    static void launchSpanStart(const char* spanName, const char* parentSpanName);

    /**
     * [性能] 设置启动Span结束打点
     * @param spanName span名称
     */
    static void launchSpanEnd(const char* spanName);

    /**
     * [性能] 标记启动完成
     */
    static void reportAppFullLaunch();

    /**
     *  [测试] 测试crash
     *  crashType: 100->java Crash
     *             101->native Crash
     *             102->anr Crash
     */
    static void TestCrash(int crashType);
    
    /**
     * 日志级别
     */
    enum class CRLogLevel{ Off=0, Error=1,Warning=2,Info=3,Debug=4,Verbose=5 };
    
    /**
     *    @brief 自定义日志,只有iOS有效。Android会自动上报adb log日志
     *        
     *    @note  日志有缓存，缓存大小为10，超过缓存大小后会自动将缓存写入文件。
     *           要让此接口生效，则必须在初始化前调用setBuglyPluginArray接口启用"BuglyLoggerPlugin"模块，并在sdk配置用开启相关配置开关
     *    @param level 日志级别 {@link CRLogLevel}
     *    @param tag   日志标签
     *    @param fmt   日志内容
     *    @param ...   动态参数
     */
    static void logBuffer(CrashReport::CRLogLevel level, const char* tag, const char* fmt, ...);

    /**
     *    @brief 将logBuffer的日志缓存写入文件。每写入10条log会自动将缓存写入文件，业务也可以手动调用flushLog将缓存写入文件
     *        
     *    @note  调用该接口后，logBuffer的日志缓存会清空
     */
    static void flushLog();

    /**
     *    @brief iOS平台接口，设置需要开启的bugly 功能模块，如果业务不调用该接口，则默认开启{"BuglyCrashMonitorPlugin", "RMMemoryMonitorPlugin"}
     *           如果需要启用logBuffer功能，则需要额外开启"BuglyLoggerPlugin"模块，即：
     *           const char* plugins[] = {"BuglyCrashMonitorPlugin", "RMMemoryMonitorPlugin", "BuglyLoggerPlugin"};
                 CrashReport::setBuglyPluginArray(3, plugins);
     */
    static void setBuglyPluginArray(int count, const char** plugins);

    CrashReport();
private:
    static bool initialized;
    static bool hasSetGameType;
    static int crashReporterType;
};

#endif
